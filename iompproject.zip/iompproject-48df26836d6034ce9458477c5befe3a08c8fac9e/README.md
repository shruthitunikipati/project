# iompproject
A machine learning project that predicts used car prices using Linear Regression. It analyzes features like brand, year, mileage, and fuel type to estimate resale value. Includes data preprocessing, model training, and a Flask-based user interface for predictions.
